package com.awt.elm.activity;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.awt.elm.R;
import com.awt.elm.adapter.EmployeeAdapter;
import com.awt.elm.model.EmployeeModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class EmployeeListActivity extends AppCompatActivity
{
    // CONNECTION_TIMEOUT and READ_TIMEOUT are in milliseconds
    public static final int CONNECTION_TIMEOUT = 10000;
    public static final int READ_TIMEOUT = 15000;
    private RecyclerView mRVFishPrice;
    private SwipeRefreshLayout swipeRefreshLayout;
    private EmployeeAdapter mAdapter;
    List<EmployeeModel> employeeModelList = new ArrayList<>();

    private boolean localDbHasData = false;
    private boolean loading = true;
    private int pageCounter = 1;
    private int pastVisibleItems;
    private int visibleItemCount;
    private int totalItemCount;
    private RelativeLayout noItemLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_list);
        mRVFishPrice = (RecyclerView)findViewById(R.id.recyclerViewList);
        swipeRefreshLayout = (SwipeRefreshLayout)findViewById(R.id.swiperefresh);
        noItemLayout = (RelativeLayout)findViewById(R.id.noItemLayout);
        // Setup and Handover data to recyclerview
        mAdapter = new EmployeeAdapter(EmployeeListActivity.this, employeeModelList);
        mRVFishPrice.setAdapter(mAdapter);
        mRVFishPrice.setLayoutManager(new LinearLayoutManager(EmployeeListActivity.this));
        new AsyncFetch().execute();

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loading = false;

                new AsyncFetch().execute();

            }
        });

    }

    private class AsyncFetch extends AsyncTask<String,String,String>
    {
        ProgressDialog pdLoading = new ProgressDialog(EmployeeListActivity.this);

        HttpURLConnection connection ;

        URL url = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            //this method will be running on UI thread
            pdLoading.setMessage("\tLoading...");
            pdLoading.setCancelable(false);
            pdLoading.show();

        }

        @Override
        protected String doInBackground(String... strings)
        {
            try
            {
                url = new URL("http://52.77.254.138/gtalent/upload/emp_data.json");


                connection = (HttpURLConnection) url.openConnection();

                connection.setReadTimeout(READ_TIMEOUT);
                connection.setConnectTimeout(CONNECTION_TIMEOUT);
                connection.setRequestMethod("GET");
                connection.setDoOutput(true);

                int response_code = connection.getResponseCode();

                if(response_code == HttpURLConnection.HTTP_OK)
                {
                    InputStream inputStream =connection.getInputStream();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                    StringBuilder result = new StringBuilder();


                    String line;

                    while ((line = reader.readLine())!=null)
                    {
                        result.append(line);

                    }

                    return result.toString();
                }
                else
                {
                    return ("unsuccessful");
                }

            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();

            }
            finally {
                connection.disconnect();
            }



        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            pdLoading.dismiss();
            swipeRefreshLayout.setRefreshing(false);
            if(result!=null)
            {
                try {

                    JSONArray jArray = new JSONArray(result);

                    // Extract data from json and store into ArrayList as class objects
                    for(int i=0;i<jArray.length();i++){
                        JSONObject json_data = jArray.getJSONObject(i);
                        EmployeeModel employeeModel = new EmployeeModel();


                        employeeModel.setEmployee_id(json_data.getLong("employee_id"));
                        employeeModel.setEmployee_name(json_data.getString("employee_name"));
                        employeeModel.setEmployee_photo(json_data.getString("employee_photo"));
                        employeeModel.setEmployee_age(json_data.getString("employee_age"));
                        employeeModel.setEmployee_gender(json_data.getString("employee_gender"));
                        employeeModel.setEmployee_designation(json_data.getString("employee_designation"));
                        employeeModel.setEmployee_leave(json_data.getString("employee_leave"));

                        employeeModelList.add(employeeModel);
                    }

                    mAdapter.notifyDataSetChanged();

                    if(employeeModelList.size() == 0)
                    {
                        Toast.makeText(EmployeeListActivity.this, "No Emplyee Found", Toast.LENGTH_LONG).show();
                        noItemLayout.setVisibility(View.GONE);
                    }

                } catch (JSONException e) {
                    Toast.makeText(EmployeeListActivity.this, e.toString(), Toast.LENGTH_LONG).show();
                    noItemLayout.setVisibility(View.GONE);
                }
            }
            else
            {
                Toast.makeText(EmployeeListActivity.this, "Error", Toast.LENGTH_LONG).show();
                noItemLayout.setVisibility(View.GONE);

            }




        }
    }
}
