package com.awt.elm.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.awt.elm.R;
import com.awt.elm.model.EmployeeModel;

public class AboutEmployeeFragment extends Fragment
{
    private AppCompatTextView empNameTV,empAgeTV,empGenderTV,empDesignationTV;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_about_tab, container, false);

        empNameTV = (AppCompatTextView)rootView.findViewById(R.id.empNameTV);
        empAgeTV = (AppCompatTextView)rootView.findViewById(R.id.empAgeTV);
        empGenderTV = (AppCompatTextView)rootView.findViewById(R.id.empGenderTV);
        empDesignationTV = (AppCompatTextView)rootView.findViewById(R.id.empDesignationTV);
        setEmployeeData();
        return rootView;

    }

    private void setEmployeeData()
    {
        EmployeeModel employeeModel = (EmployeeModel) getActivity().getIntent().getSerializableExtra("empData");


        empNameTV.setText(employeeModel.getEmployee_name());

        empAgeTV.setText(employeeModel.getEmployee_age());

        empGenderTV.setText(employeeModel.getEmployee_gender());

        empDesignationTV.setText(employeeModel.getEmployee_designation());

    }
}
