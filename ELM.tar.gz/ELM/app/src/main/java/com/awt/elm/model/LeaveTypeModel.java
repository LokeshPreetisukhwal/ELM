package com.awt.elm.model;

public class LeaveTypeModel
{
    private int id;
    private String leaveTypeName;

    public LeaveTypeModel(int id, String leaveTypeName) {
        this.id = id;
        this.leaveTypeName = leaveTypeName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLeaveTypeName() {
        return leaveTypeName;
    }

    public void setLeaveTypeName(String leaveTypeName) {
        this.leaveTypeName = leaveTypeName;
    }
}
