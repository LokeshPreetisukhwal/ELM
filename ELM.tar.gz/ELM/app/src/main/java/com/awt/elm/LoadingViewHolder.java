package com.awt.elm;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ProgressBar;

public class LoadingViewHolder extends RecyclerView.ViewHolder {
    public ProgressBar progressBar;

    public LoadingViewHolder(View itemView) {
        super(itemView);
        progressBar = (ProgressBar) itemView.findViewById(R.id.loading_progressBar);
    }
}