package com.awt.elm.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;

import com.awt.elm.R;
import com.awt.elm.model.EmployeeModel;

public class EmployeeDetailActivity extends AppCompatActivity implements AppBarLayout.OnOffsetChangedListener, View.OnClickListener
{

    private AppBarLayout appbarLayout;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private FloatingActionButton fab_apply_leave;
    private AppCompatTextView userName;
    private CoordinatorLayout mCoordinatorLayout;

    private static final int PERCENTAGE_TO_ANIMATE_AVATAR = 20;
    private static final int ACTION_START_EDIT_PROFILE = 1;


    TabsAdapter mTabsAdapter;
    private boolean mIsAvatarShown = true;
    private int mMaxScrollSize;
    private String profileImageSharedPrefernces;
    private Boolean canEditProfile=false;
    SharedPreferences sharedPreferences;


    private Toolbar employee_detail_toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_detail);
        init();
    }

    private void init()
    {
        tabLayout        = (TabLayout) findViewById(R.id.employee_tabs);
        viewPager        = (ViewPager) findViewById(R.id.employee_viewpager);
        appbarLayout     = (AppBarLayout) findViewById(R.id.appbar);
        employee_detail_toolbar = (Toolbar) findViewById(R.id.employee_detail_toolbar);
        mCoordinatorLayout = (CoordinatorLayout) findViewById(R.id.coordinator);
        fab_apply_leave   = (FloatingActionButton) findViewById(R.id.fab_apply_leave);


        fab_apply_leave.setOnClickListener(this);



        EmployeeModel employeeModel = (EmployeeModel) getIntent().getSerializableExtra("empData");
        setSupportActionBar(employee_detail_toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("");

        mTabsAdapter = new TabsAdapter(getSupportFragmentManager());
        viewPager.setAdapter(mTabsAdapter);
        tabLayout.setupWithViewPager(viewPager);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                if(position == 0){
                    fab_apply_leave.animate()
                            .scaleY(1).scaleX(1)
                            .start();
                    fab_apply_leave.setVisibility(View.VISIBLE);


                }else{
                    fab_apply_leave.animate().scaleY(0).scaleX(0).setDuration(200).start();
                    fab_apply_leave.setVisibility(View.GONE);
                }
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

    }


    @Override
    public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.fab_apply_leave :

                Intent intent = new Intent(this, AddLeaveActivity.class);
                startActivity(intent);
                break;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        switch (id){
            case android.R.id.home:
                finish();
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    class TabsAdapter extends FragmentStatePagerAdapter {
        public TabsAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public int getCount() {
            return 2;
        }

        @Override
        public Fragment getItem(int i) {
            switch(i) {
                case 0: return new AboutEmployeeFragment();
                case 1: return new LeaveListFragment();
                /*case 2: return new MoreTabFragment();*/

            }
            return null;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch(position) {
                case 0: return "About";
                case 1: return "Leave List";
                case 2: return "More";
            }
            return "";
        }


    }

}
