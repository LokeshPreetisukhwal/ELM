package com.awt.elm.model;

import java.io.Serializable;

public class EmployeeModel implements Serializable
{
    private Long employee_id ;
    private String employee_name;
    private String employee_photo;
    private String employee_age;
    private String employee_gender;
    private String employee_designation;
    private String employee_leave;

    public EmployeeModel()
    {

    }
    public EmployeeModel(Long employee_id, String employee_name, String employee_photo, String employee_age, String employee_gender, String employee_designation, String employee_leave)
    {
        this.employee_id = employee_id;
        this.employee_name = employee_name;
        this.employee_photo = employee_photo;
        this.employee_age = employee_age;
        this.employee_gender = employee_gender;
        this.employee_designation = employee_designation;
        this.employee_leave = employee_leave;
    }

    public Long getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(Long employee_id) {
        this.employee_id = employee_id;
    }

    public String getEmployee_name() {
        return employee_name;
    }

    public void setEmployee_name(String employee_name) {
        this.employee_name = employee_name;
    }

    public String getEmployee_photo() {
        return employee_photo;
    }

    public void setEmployee_photo(String employee_photo) {
        this.employee_photo = employee_photo;
    }

    public String getEmployee_age() {
        return employee_age;
    }

    public void setEmployee_age(String employee_age) {
        this.employee_age = employee_age;
    }

    public String getEmployee_gender() {
        return employee_gender;
    }

    public void setEmployee_gender(String employee_gender) {
        this.employee_gender = employee_gender;
    }

    public String getEmployee_designation() {
        return employee_designation;
    }

    public void setEmployee_designation(String employee_designation) {
        this.employee_designation = employee_designation;
    }

    public String getEmployee_leave() {
        return employee_leave;
    }

    public void setEmployee_leave(String employee_leave) {
        this.employee_leave = employee_leave;
    }
}
