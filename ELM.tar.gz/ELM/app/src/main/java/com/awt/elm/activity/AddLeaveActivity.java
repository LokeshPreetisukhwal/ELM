package com.awt.elm.activity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatSpinner;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TimePicker;

import com.awt.elm.R;
import com.awt.elm.adapter.LeaveAdapter;
import com.awt.elm.model.LeaveTypeModel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class AddLeaveActivity extends AppCompatActivity implements View.OnClickListener {

    private List<LeaveTypeModel> leaveTypeModelList;
    private LeaveAdapter leaveAdapter;
    private AppCompatSpinner leaveTypeSpinner;

    private List<LeaveTypeModel> leaveDaysModelList;
    private LeaveAdapter leaveDaysAdapter;
    private AppCompatSpinner leaveDaysSpinner;

    private AppCompatEditText fromDate,fromTime,toDate,toTime,resonTxt;
    private DatePickerDialog mFromDatePickerDialog;
    private DatePickerDialog mToDatePickerDialog;
    private SimpleDateFormat dateFormatter;
    Calendar mCalendar = Calendar.getInstance();
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_leave);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle(getString(R.string.add_leave));
        leaveTypeSpinner =(AppCompatSpinner)findViewById(R.id.leaveTypeSpinner);
        leaveDaysSpinner =(AppCompatSpinner)findViewById(R.id.leaveDaysSpinner);

        fromDate =(AppCompatEditText)findViewById(R.id.fromDate);
        fromTime =(AppCompatEditText)findViewById(R.id.fromTime);
        toDate =(AppCompatEditText)findViewById(R.id.toDate);
        toTime =(AppCompatEditText)findViewById(R.id.toTime);
        resonTxt =(AppCompatEditText)findViewById(R.id.leaveResonET);

        dateFormatter = new SimpleDateFormat("dd-MM-yyyy");


        setLeaveTypeList();
        setLeaveDaysList();
        setDateTimeField();
        setLeaveOnClick();
    }


private void setLeaveOnClick()
{

    fromDate.setInputType(InputType.TYPE_NULL);
    fromTime.setInputType(InputType.TYPE_NULL);
    toDate.setInputType(InputType.TYPE_NULL);
    toTime.setInputType(InputType.TYPE_NULL);

    fromDate.setOnClickListener(this);
    fromTime.setOnClickListener(this);
    toDate.setOnClickListener(this);
    toTime.setOnClickListener(this);

}

    private void setDateTimeField() {
        fromDate.setOnClickListener(this);

        Calendar newCalendar = Calendar.getInstance();
        mFromDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                mCalendar.set(Calendar.YEAR, year);
                mCalendar.set(Calendar.MONTH, monthOfYear);
                mCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                fromDate.setText(dateFormatter.format(mCalendar.getTime()));

            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

        mToDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                mCalendar.set(Calendar.YEAR, year);
                mCalendar.set(Calendar.MONTH, monthOfYear);
                mCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                toDate.setText(dateFormatter.format(mCalendar.getTime()));

            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        switch (id){
            case android.R.id.home:
                finish();
                return true;

        }
        return super.onOptionsItemSelected(item);
    }
    private void setLeaveTypeList()
    {
        leaveTypeModelList = new ArrayList<>();
        leaveTypeModelList.add(new LeaveTypeModel(-1,"Select Leave Type"));
        leaveTypeModelList.add(new LeaveTypeModel(1,"Casual Leave"));
        leaveTypeModelList.add(new LeaveTypeModel(2,"Sick Leave"));

        leaveAdapter = new LeaveAdapter(this,android.R.layout.simple_spinner_item,leaveTypeModelList);
        leaveTypeSpinner.setAdapter(leaveAdapter);

    }

    private void setLeaveDaysList()
    {
        leaveDaysModelList = new ArrayList<>();
        leaveDaysModelList.add(new LeaveTypeModel(-1,"Select Leave Days"));
        leaveDaysModelList.add(new LeaveTypeModel(31,"Half Day"));

        for(int i=1;i<=31;i++)
        {
            leaveDaysModelList.add(new LeaveTypeModel(1,i+" Day"));
        }

        leaveDaysAdapter = new LeaveAdapter(this,android.R.layout.simple_spinner_item,leaveDaysModelList);
        leaveDaysSpinner.setAdapter(leaveDaysAdapter);

    }

    @Override
    public void onClick(View v) {
        if(v == fromDate) {

            Calendar c = Calendar.getInstance();
            // c.setTimeZone(TimeZone.getTimeZone("UTC"));
            c.set(Calendar.HOUR_OF_DAY, 0);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);

            // mDatePickerDialog.getDatePicker().setMinDate(c.getTimeInMillis());
            // c.add(Calendar.DAY_OF_WEEK, 1);
            //  mDatePickerDialog.getDatePicker().setMaxDate(c.getTimeInMillis());
            mFromDatePickerDialog.show();
        }
        if(v == toDate) {

            Calendar c = Calendar.getInstance();
            // c.setTimeZone(TimeZone.getTimeZone("UTC"));
            c.set(Calendar.HOUR_OF_DAY, 0);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);

            // mDatePickerDialog.getDatePicker().setMinDate(c.getTimeInMillis());
            // c.add(Calendar.DAY_OF_WEEK, 1);
            //  mDatePickerDialog.getDatePicker().setMaxDate(c.getTimeInMillis());
            mToDatePickerDialog.show();
        }
        else if(v == fromTime)
        {
            final Calendar mcurrentTime = Calendar.getInstance();
            int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
            int minute = mcurrentTime.get(Calendar.MINUTE);
            TimePickerDialog mTimePicker;
            mTimePicker = new TimePickerDialog(AddLeaveActivity.this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                    mCalendar.set(Calendar.HOUR_OF_DAY, selectedHour);
                    mCalendar.set(Calendar.MINUTE, selectedMinute);
                    fromTime.setText(getDateInString(mCalendar.getTimeInMillis(),false));


                }
            }, hour, minute, true);//Yes 24 hour time
            mTimePicker.setTitle("Select Time");
            mTimePicker.show();
        }
        else if(v == toTime)
        {
            final Calendar mcurrentTime = Calendar.getInstance();
            int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
            int minute = mcurrentTime.get(Calendar.MINUTE);
            TimePickerDialog mTimePicker;
            mTimePicker = new TimePickerDialog(AddLeaveActivity.this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                    mCalendar.set(Calendar.HOUR_OF_DAY, selectedHour);
                    mCalendar.set(Calendar.MINUTE, selectedMinute);
                    toTime.setText(getDateInString(mCalendar.getTimeInMillis(),false));


                }
            }, hour, minute, true);//Yes 24 hour time
            mTimePicker.setTitle("Select Time");
            mTimePicker.show();
        }
    }


    private String getDateInString(Long complainOpenTimestamp,boolean flagOfDate) {

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(complainOpenTimestamp);
        if(flagOfDate)
        {
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            Date now = new Date(complainOpenTimestamp);
            return  sdf.format(now);
        }
        else
        {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
            int hours = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);
            String hour_value = "";
            String minute_value = "";

            if(hours<10)
            {
                hour_value = "0"+hours;
            }else
            {
                hour_value = ""+hours;

            }
            if(minute<10)
            {
                minute_value  =  "0"+minute;
            }
            else
            {
                minute_value  =  ""+minute;

            }

            return  hour_value+":"+minute_value;
        }


    }
}
