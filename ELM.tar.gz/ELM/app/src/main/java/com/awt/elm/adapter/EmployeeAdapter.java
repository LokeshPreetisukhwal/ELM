package com.awt.elm.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.awt.elm.LoadingViewHolder;
import com.awt.elm.R;
import com.awt.elm.model.EmployeeModel;
import com.awt.elm.viewholder.EmployeeViewHolder;

import java.util.List;

public class EmployeeAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>
{
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;

    List<EmployeeModel> employeeModels;
    private Context context;

    public EmployeeAdapter(Context context,List<EmployeeModel> employeeModels)
    {
        this.context = context;
        this.employeeModels = employeeModels;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType)
    {
        if (viewType == VIEW_TYPE_ITEM) {
                View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.employee_list_item, viewGroup, false);
                return new EmployeeViewHolder(view, context);


        }
        else if (viewType == VIEW_TYPE_LOADING) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.layout_loading_item, viewGroup, false);
            return new LoadingViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder itemViewHolder, int position)
    {
        if (itemViewHolder instanceof EmployeeViewHolder) {
            final EmployeeModel model = employeeModels.get(position);
            EmployeeViewHolder viewHolder = (EmployeeViewHolder) itemViewHolder;
            viewHolder.onBind(model, position);

        }else if (itemViewHolder instanceof LoadingViewHolder) {
            LoadingViewHolder loadingViewHolder = (LoadingViewHolder) itemViewHolder;
            loadingViewHolder.progressBar.setIndeterminate(true);
        }
    }

    @Override
    public int getItemViewType(int position) {

        return employeeModels.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    @Override
    public int getItemCount() {
        return employeeModels == null ? 0 : employeeModels.size();
    }

    /** Filter Logic**/
    public void animateTo(List<EmployeeModel> models) {
        applyAndAnimateRemovals(models);
        applyAndAnimateAdditions(models);
        applyAndAnimateMovedItems(models);

    }

    private void applyAndAnimateRemovals(List<EmployeeModel> newModels) {


        for (int i = employeeModels.size() - 1; i >= 0; i--) {
            final EmployeeModel model = employeeModels.get(i);
            if (!newModels.contains(model)) {
                removeItem(i);
            }
        }
    }

    private void applyAndAnimateAdditions(List<EmployeeModel> newModels) {

        for (int i = 0, count = newModels.size(); i < count; i++) {
            final EmployeeModel model = newModels.get(i);
            if (!employeeModels.contains(model)) {
                addItem(i, model);
            }
        }
    }

    private void applyAndAnimateMovedItems(List<EmployeeModel> newModels) {
        for (int toPosition = newModels.size() - 1; toPosition >= 0; toPosition--) {
            final EmployeeModel model = newModels.get(toPosition);
            final int fromPosition = employeeModels.indexOf(model);
            if (fromPosition >= 0 && fromPosition != toPosition) {
                moveItem(fromPosition, toPosition);
            }
        }
    }

    public EmployeeModel removeItem(int position) {
        final EmployeeModel model = employeeModels.remove(position);
        notifyItemRemoved(position);
        return model;
    }

    public void addItem(int position, EmployeeModel model) {
        employeeModels.add(position, model);
        notifyItemInserted(position);
    }

    public void moveItem(int fromPosition, int toPosition) {
        final EmployeeModel model = employeeModels.remove(fromPosition);
        employeeModels.add(toPosition, model);
        notifyItemMoved(fromPosition, toPosition);
    }

}
