package com.awt.elm.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.awt.elm.R;

public class MainActivity extends AppCompatActivity {

    /**
     * Declare class variables
     */
    private final int DELAY_INTERVAL = 3 * 1000;
    private CountDownTimer mCountDownTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startCountDownTimer();
    }



    /**
     * Functionality to delay time and start with login_frag view
     */
    void startCountDownTimer() {
        mCountDownTimer = new CountDownTimer(DELAY_INTERVAL, DELAY_INTERVAL) {
            @Override
            public void onTick(long millisUntilFinished) {
                // do nothing
            }

            @Override
            public void onFinish() {
                //start screen

                Intent intent = new Intent(MainActivity.this,EmployeeListActivity.class);
                startActivity(intent);
                finish();
            }
        }.start();
    }

    private void stopCountDownTimer() {
        if (mCountDownTimer != null) {
            mCountDownTimer.cancel();
            mCountDownTimer = null;
        }
    }




    @Override
    public void onBackPressed() {
        //user forcefully come out from the application thus stop timer
        stopCountDownTimer();
        super.onBackPressed();
    }

}
