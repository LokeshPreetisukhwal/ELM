package com.awt.elm.viewholder;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.awt.elm.R;
import com.awt.elm.activity.EmployeeDetailActivity;
import com.awt.elm.model.EmployeeModel;

import java.io.InputStream;

public class EmployeeViewHolder extends RecyclerView.ViewHolder
{

    private TextView empNameTxt,empDesinationTxt;
    private ImageView empPhotoTxt;
    private RelativeLayout parentpayout;

    private Context context;
    public EmployeeViewHolder(View itemView, Context context)
    {
        super(itemView);
        this.context = context;
        empNameTxt = (TextView)itemView.findViewById(R.id.textFishName);
        empDesinationTxt = (TextView)itemView.findViewById(R.id.textType);
        parentpayout = (RelativeLayout) itemView.findViewById(R.id.layoutss);
    }

    public void onBind(final EmployeeModel employeeModel, int position)
    {

        empNameTxt.setText(employeeModel.getEmployee_name());
        empDesinationTxt.setText(employeeModel.getEmployee_designation());
        parentpayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent  = new Intent(context, EmployeeDetailActivity.class);
                intent.putExtra("empData",employeeModel);
                context.startActivity(intent);
            }
        });


    }
}
