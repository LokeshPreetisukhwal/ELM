package com.awt.elm.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.awt.elm.R;
import com.awt.elm.model.LeaveTypeModel;

import java.util.List;

public class LeaveAdapter extends ArrayAdapter<LeaveTypeModel> {


    private Activity activitySpinner;
    private List<LeaveTypeModel> data;
    LeaveTypeModel tempValues = null;
    LayoutInflater inflater;

    public LeaveAdapter(Activity activitySpinner, int textViewResourceId,
                            List<LeaveTypeModel> objects) {
        super(activitySpinner, textViewResourceId, objects);
        activitySpinner = activitySpinner;
        data = objects;
        inflater = (LayoutInflater) activitySpinner.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        return getCustomView(position, convertView, parent);
    }

    // This function called for each row ( Called data.size() times )
    public View getCustomView(int position, View convertView, ViewGroup parent) {

        View row = inflater.inflate(R.layout.category_spinner_row, parent, false);

        tempValues = null;
        tempValues = (LeaveTypeModel) data.get(position);

        TextView label = (TextView) row.findViewById(R.id.category_item);

        // Set values for spinner each row
        label.setText(tempValues.getLeaveTypeName());

        return row;
    }


}