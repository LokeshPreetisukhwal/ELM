package com.droid.manasshrestha.myapplication;

public interface AnimationViewChangeListener {
    void onAnimationChanged(int position);
}
